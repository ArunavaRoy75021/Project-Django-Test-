from django.db import models
from django.utils.translation import ugettext_lazy as _
#  from django.utils.dateparse import parse_duration


# model for student table 
class Student(models.Model):
    Stname = models.CharField(max_length=35, null=True, blank=True)
    Stdob = models.DateField(null=True, blank=True)
    Rollno = models.CharField(max_length=35, null=True, blank=True)
    Classs = models.CharField(max_length=40, null=True, blank=True)
    address = models.CharField(max_length=100, null=True, blank=True)
    zipcode = models.CharField(max_length=20, null=True, blank=True)

#model for attandence
class Atten(models.Model):
    Nam = models.CharField(max_length=35, null=True, blank=True)
    Rolno = models.CharField(max_length=35, null=True, blank=True)
    Clsss = models.CharField(max_length=40, null=True, blank=True)
    Dte = models.DateField(null=True, blank=True)
    Day = models.CharField(max_length=40, null=True, blank=True)
