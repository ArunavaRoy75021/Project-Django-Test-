from django.contrib import admin
from django.urls import path
from SAMS import views

urlpatterns = [
    path('Createstudent',views.createStudent, name="createstudent"),
    path('Studentlist',views.Studentlist, name="Studentlist"),
    path('Attenda',views.Attsheet, name="Attan"),
    path('deletestud/<int:pid>',views.deletestudent, name="deletestudent"),
    # path('leave-status/<int:pid>',views.leave_status, name="leave_status"),

]