from django.shortcuts import render, HttpResponseRedirect
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import redirect
from .models import *



# Creating a Student

def createStudent(request):
    if request.method == "POST":
        Stname = request.POST['name']
        Stdob = request.POST['dob']
        Rollno = request.POST['Rollno']
        Classs = request.POST['Class']
        address = request.POST['address']
        zipcode = request.POST['zipcode']
        stud_obj = Student.objects.create(Stname=Stname,Stdob=Stdob,Rollno=Rollno,address=address,Classs=Classs,zipcode=zipcode)
        messages.success(request, "Student created successfully")
        return redirect('studform')
    return render(request, 'createstudent.html')


# Listing of a Student
def Studentlist(request):
    sm_dta = Student.objects.filter()
    bit = {'Student':sm_dta}
    return render(request, 'studform.html',bit)


# Deleting of a Student
def deletestudent(request, pid):
    dta = Student.objects.get(Rollno=pid)
    dta.delete()
    messages.success(request, "Student Deleted successfully")
    return redirect('Studentlist')


# Attandance sheet 
def Attsheet(request):
    if request.method == "POST":
        Nam = request.POST['Nam']
        Rolno = request.POST['Rolno']
        Clsss = request.POST['Class']
        Dte = request.POST['Date']
        Day = request.POST['DAY']
        Att_obj = Atten.objects.create(Nam=Nam,Rolno=Rolno,Clsss=Clsss,Dte=Dte,Day=Day)
        messages.success(request, "Attandance marked successfully")
        return redirect('studform')
    return render(request, 'Attendance.html')


# Attandance Percentage 
